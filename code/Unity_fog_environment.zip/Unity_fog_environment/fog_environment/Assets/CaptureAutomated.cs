using UnityEngine;
using System.IO;
using System.Collections;

public class CaptureAutomated : MonoBehaviour
{
    public Camera captureCamera;
    public Transform checkerboard;

    public int width = 1920;
    public int height = 1080;

    public float moveStepSize = 1f;   // 1 unit per step
    public float rotationStep = 3f;   // degrees per step

    private string folderPath = @"C:\Users\Admin\Desktop\saved_images\NEW_FOLDER\NO_FOG";

    private bool isCapturing = false;
    private int imageIndex = 0;

    void Start()
    {
        if (captureCamera == null || checkerboard == null)
        {
            Debug.LogError("Assign Camera and Checkerboard!");
            return;
        }

        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.L) && !isCapturing)
        {
            StartCoroutine(AutoCaptureSequence());
        }
    }

    IEnumerator AutoCaptureSequence()
    {
        isCapturing = true;
        imageIndex = 0;

        Vector3 startPos = captureCamera.transform.position;
        Quaternion startRot = captureCamera.transform.rotation;

        // 🔹 UP
        yield return MoveAndCapture(Vector3.up);

        captureCamera.transform.position = startPos;

        // 🔹 DOWN
        yield return MoveAndCapture(Vector3.down);

        captureCamera.transform.position = startPos;

        // 🔹 LEFT
        yield return MoveAndCapture(Vector3.left);

        captureCamera.transform.position = startPos;

        // 🔹 RIGHT
        yield return MoveAndCapture(Vector3.right);

        captureCamera.transform.position = startPos;

        // 🔹 ROTATE CLOCKWISE
        yield return RotateAndCapture();

        Debug.Log("✅ Finished 20 image capture sequence");
        isCapturing = false;
    }

    IEnumerator MoveAndCapture(Vector3 direction)
    {
        for (int i = 0; i < 4; i++)
        {
            captureCamera.transform.position += direction * moveStepSize;

            yield return new WaitForEndOfFrame();

            CaptureAndSave(imageIndex++);
            yield return new WaitForSeconds(0.05f);
        }
    }

    IEnumerator RotateAndCapture()
    {
        for (int i = 0; i < 4; i++)
        {
            captureCamera.transform.Rotate(Vector3.up, rotationStep, Space.World);

            yield return new WaitForEndOfFrame();

            CaptureAndSave(imageIndex++);
            yield return new WaitForSeconds(0.05f);
        }
    }

    float GetDistanceToCheckerboard()
    {
        return Vector3.Distance(
            captureCamera.transform.position,
            checkerboard.position
        );
    }

    void CaptureAndSave(int index)
    {
        RenderTexture rt = new RenderTexture(width, height, 24);
        captureCamera.targetTexture = rt;

        Texture2D image = new Texture2D(width, height, TextureFormat.RGB24, false);

        captureCamera.Render();

        RenderTexture.active = rt;
        image.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        image.Apply();

        captureCamera.targetTexture = null;
        RenderTexture.active = null;
        Destroy(rt);

        byte[] bytes = image.EncodeToPNG();

        string fileName = "capture_" + index.ToString("D2") + ".png";
        string fullPath = Path.Combine(folderPath, fileName);

        File.WriteAllBytes(fullPath, bytes);

        float dist = GetDistanceToCheckerboard();

        Debug.Log($"Saved: {fileName} | Distance: {dist:F3} m");
    }
}