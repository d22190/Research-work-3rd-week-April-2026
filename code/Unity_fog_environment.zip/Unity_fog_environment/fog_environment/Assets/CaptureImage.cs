using UnityEngine;
using System.IO;

public class CaptureImage : MonoBehaviour
{
    public Camera captureCamera;

    // ✅ ADD THIS: drag checkerboard object in Inspector
    public Transform checkerboard;

    public int width = 1920;
    public int height = 1080;

    public float moveSpeed = 5f;
    public float rotationSpeed = 100f;

    private string folderPath = @"C:\Users\Admin\Downloads\UnityCapture\UnityCaptureSample\Assets\captured_images";

    void Start()
    {
        if (captureCamera == null)
        {
            Debug.LogError("Capture Camera not assigned!");
            return;
        }

        if (checkerboard == null)
        {
            Debug.LogError("Checkerboard not assigned!");
            return;
        }

        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }
    }

    void Update()
    {
        HandleMovement();
        HandleRotation();

        // ✅ Continuously print distance (optional)
        float dist = GetDistanceToCheckerboard();
        Debug.Log("Distance to checkerboard: " + dist.ToString("F3") + " meters");

        if (Input.GetKeyDown(KeyCode.Space))
        {
            CaptureAndSave();
        }
    }

    float GetDistanceToCheckerboard()
    {
        return Vector3.Distance(
            captureCamera.transform.position,
            checkerboard.position
        );
    }

    void HandleMovement()
    {
        float moveStep = moveSpeed * Time.deltaTime;

        if (Input.GetKey(KeyCode.W))
            captureCamera.transform.position += captureCamera.transform.forward * moveStep;

        if (Input.GetKey(KeyCode.S))
            captureCamera.transform.position -= captureCamera.transform.forward * moveStep;

        if (Input.GetKey(KeyCode.A))
            captureCamera.transform.position -= captureCamera.transform.right * moveStep;

        if (Input.GetKey(KeyCode.D))
            captureCamera.transform.position += captureCamera.transform.right * moveStep;

        if (Input.GetKey(KeyCode.E))
            captureCamera.transform.position += captureCamera.transform.up * moveStep;

        if (Input.GetKey(KeyCode.Q))
            captureCamera.transform.position -= captureCamera.transform.up * moveStep;
    }

    void HandleRotation()
    {
        float rotStep = rotationSpeed * Time.deltaTime;

        if (Input.GetKey(KeyCode.LeftArrow))
            captureCamera.transform.Rotate(Vector3.up, -rotStep, Space.World);

        if (Input.GetKey(KeyCode.RightArrow))
            captureCamera.transform.Rotate(Vector3.up, rotStep, Space.World);

        if (Input.GetKey(KeyCode.UpArrow))
            captureCamera.transform.Rotate(Vector3.right, -rotStep, Space.Self);

        if (Input.GetKey(KeyCode.DownArrow))
            captureCamera.transform.Rotate(Vector3.right, rotStep, Space.Self);

        if (Input.GetKey(KeyCode.Z))
            captureCamera.transform.Rotate(Vector3.forward, rotStep, Space.Self);

        if (Input.GetKey(KeyCode.X))
            captureCamera.transform.Rotate(Vector3.forward, -rotStep, Space.Self);
    }

    void CaptureAndSave()
    {
        RenderTexture rt = new RenderTexture(width, height, 24);
        captureCamera.targetTexture = rt;

        Texture2D image = new Texture2D(width, height, TextureFormat.RGB24, false);

        captureCamera.Render();

        RenderTexture.active = rt;
        image.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        image.Apply();

        captureCamera.targetTexture = null;
        RenderTexture.active = null;
        Destroy(rt);

        byte[] bytes = image.EncodeToPNG();

        string fileName = "capture_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png";
        string fullPath = Path.Combine(folderPath, fileName);

        File.WriteAllBytes(fullPath, bytes);

        // ✅ ALSO SAVE DISTANCE WITH IMAGE
        float dist = GetDistanceToCheckerboard();
        Debug.Log("Saved Image: " + fullPath + " | Distance: " + dist.ToString("F3") + " meters");
    }
}